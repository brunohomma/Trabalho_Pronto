#ifndef _REGISTRO2_H_
#define _REGISTRO2_H_

void importaRegistro_metodo2(FILE *);

#endif