#ifndef _INTERFACE_H_
#define _INTERFACE_H_

void interfaceInicial();
void interfaceFacial();
void apagaTela();

#endif