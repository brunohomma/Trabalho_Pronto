#ifndef _LEITURAARQUIVOBINARIO_H_
#define _LEITURAARQUIVOBINARIO_H_

void lerArquivoBinario();
void buscaCampo(int, int);
void buscaRegistro(int);

#endif